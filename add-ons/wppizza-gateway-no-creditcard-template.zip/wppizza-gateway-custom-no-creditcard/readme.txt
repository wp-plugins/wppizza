=== WPPizza Gateway Custom===
Contributors: ollybach
Donate link: http://www.wp-pizza.com/
Author URI: http://www.wp-pizza.com
Plugin URI: http://wordpress.org/extend/plugins/wppizza/
Tags: paypal, gateway, wppizza
Requires at least: WPPIZZA 2.4, WP 3.5.1 
Tested up to: 3.5.1
Stable tag: 0.1


Custom Gateway for WPPizza - Requires WPPIZZA 2.4+

== Description ==

Custom Gateway for WPPizza - Custom Gateway for orders using the Wordpress WPPIZZA Plugin - Requires WPPIZZA 2.4+
